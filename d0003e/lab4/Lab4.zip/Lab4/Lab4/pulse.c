#include "pulse.h"

void generatePulse(pulse* self) {
	if (self->freq > 0) {
		ASYNC(self->w, port1, self->bit);
		self->savedMsg = AFTER(MSEC(500)/self->freq , self, generatePulse, 0);
	} else {
		ASYNC(self->w, port0, self->bit);
		self->savedMsg = NULL;
	}
}

void hold(pulse* self, int pos){
	if(self->HoldMsg != NULL){
		ABORT(self->HoldMsg);
	}
	if(((PINB >> 6) & 1) == 0){
		ASYNC(self, increase, pos);
		self->HoldMsg = AFTER(MSEC(350), self, hold, pos);
		
	}
	else if(((PINB >> 7) & 1) == 0){
		ASYNC(self, decrease, pos);
		self->HoldMsg = AFTER(MSEC(350), self, hold, pos);
	}
	else{
		self->HoldMsg = NULL;
	}
}

void increase(pulse *self, int pos) {
	if (self->freq < 99) {
		self->freq++;
		if(self->freq == 1){
			ASYNC(self, generatePulse, 0);
		}
		change(self, pos);
	}
}

void decrease(pulse *self, int pos) {
	if (self->freq > 0) {
		self->freq--;
		change(self, pos);
	}
}

void save(pulse *self, int pos) {
	if (self->freq == 0) {
		self->freq = self->savedFreq;
		if(self->savedMsg == NULL){
			ASYNC(self, generatePulse, 0);
		}
		change(self, pos);
	} else {
		self->savedFreq = self->freq;
		self->freq = 0;
		change(self, pos);
	}
	
	
}

void change(pulse* self, int pos){
	if (self->pos == 0) {
		ASYNC(self, left, self->freq);
	} else if (self->pos == 4) {
		ASYNC(self, right, self->freq);
	}
}