#ifndef SWITCH_H_
#define SWITCH_H_

#include "TinyTimber.h"
#include "pulse.h"
#include "init.h"
#include "GUI.h"
#include <avr/io.h>

typedef struct
{
	Object super;
	struct pulse *p1;
	struct pulse *p2;
	struct pulse *active;
	int pos;
} Switch;

#define initSwitch(p1, p2) {initObject(), p1, p2, p1, 0}

void joystick(Switch *self, int x);
void start(Switch *self, int x);
	
#endif