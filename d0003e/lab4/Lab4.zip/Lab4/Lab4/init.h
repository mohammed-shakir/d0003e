#ifndef INIT_H_
#define INIT_H_

#include "TinyTimber.h"
#include <avr/io.h>

void LCD_Init(void);
void IO_Init(void);

#endif