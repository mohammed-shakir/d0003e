#ifndef PULSE_H_
#define PULSE_H_

#include "TinyTimber.h"
#include "GUI.h"
#include "write.h"
#include "Switch.h"
#include <avr/io.h>

typedef struct
{
	Object super;
	struct write *w;
	int bit;
	int pos;
	long freq;
	int on;
	int savedFreq;
	Msg HoldMsg;
	Msg savedMsg;
} pulse;

#define initpulse(w, bit, pos) { initObject(), w, bit, pos, 0, 0, 0, NULL, NULL }
	
void increase(pulse *self, int pos);
void decrease(pulse *self, int pos);
void save(pulse *self, int pos);
void change(pulse* self, int pos);
void generatePulse(pulse* self);
void hold(pulse* self, int pos);

#endif