#include <avr/io.h>
#include "TinyTimber.h"
#include "GUI.h"
#include "init.h"
#include "Switch.h"
#include "pulse.h"
#include "write.h"


write w = initwriter();
pulse p1 = initpulse(&w, 4, 0);
pulse p2 = initpulse(&w, 6, 4);
Switch s = initSwitch(&p1, &p2);

int main(void)
{
	LCD_Init();
	IO_Init();
	
	INSTALL(&s, joystick, IRQ_PCINT1);
	INSTALL(&s, joystick, IRQ_PCINT0);
	
    return TINYTIMBER(&s, start, 0);
}