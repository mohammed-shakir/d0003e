#include "write.h"

void port1(write *self, int bit) {
	PORTE ^= (1<<bit);
}

void port0(write *self, int bit) {
	PORTE &= ~(1<<bit);
}