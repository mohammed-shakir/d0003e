#ifndef GUI_H_
#define GUI_H_

#include "TinyTimber.h"
#include "init.h"
#include <avr/io.h>

typedef struct
{
	Object super;
} GUI;

#define initGUI() { initObject() }

void writeChar(GUI* self, char ch, int pos);
void printAt(GUI* self, int num, int pos);
void lcd(GUI* self, int pos);
void left(GUI* self, int num);
void right(GUI* self, int num);

#endif