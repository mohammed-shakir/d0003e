#include "Switch.h"

void joystick(Switch *self, int x) {
	if (((PINB >> 7) & 1) == 0) {
		ASYNC(self->active, decrease, self->pos);
		AFTER(MSEC(500), self->active, hold, self->pos);
	}
	
	else if (((PINB >> 6) & 1) == 0) {
		ASYNC(self->active, increase, self->pos);
		AFTER(MSEC(500), self->active, hold, self->pos);
	}
	
	else if (((PINB >> 4) & 1) == 0) {
		ASYNC(self->active, save, self->pos);
	}
	
	else if (((PINE >> 2) & 1) == 0) {
		self->active = self->p1;
		self->pos = 0;
		ASYNC(self->active, lcd, self->pos);
	}
	
	else if (((PINE >> 3) & 1) == 0) {
		self->active = self->p2;
		self->pos = 4;
		ASYNC(self->active, lcd, self->pos);
	}
}

void start(Switch *self, int x) {
	LCDDR13 = 0x1;
	LCDDR3 = 0x0;
	ASYNC(self->p1, change, 0);
	ASYNC(self->p2, change, 4);
}