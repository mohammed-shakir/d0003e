#include <stdint.h>
#include "init.h"

void LCD_Init(void) {
	LCDCRB = (1<<LCDCS) | (1<<LCDMUX1) | (1<<LCDMUX0) | (1<<LCDPM2) | (1<<LCDPM1) | (1<<LCDPM0);
	LCDFRR = (1<<LCDCD2) | (1<<LCDCD1) | (1<<LCDCD0);
	LCDCCR = (1<<LCDCC3) | (1<<LCDCC2) | (1<<LCDCC1) | (1<<LCDCC0);
	LCDCRA = (1<<LCDEN)| (1<<LCDAB);
}

void IO_Init(void) {
	// Down = 7
	// Up = 6
	// Press = 4
	// Right = 3
	// Left = 2
	PORTB = (1<<7) | (1<<6) | (1<<4);
	PORTE = (1<<3) | (1<<2);
	DDRE = (1<<DDE6) | (1<<DDE4);
	PCMSK1 = (1<<PCINT15) | (1 << PCINT14) | (1<<PCINT12);
	PCMSK0 = (1<<PCINT3) | (1<<PCINT2);
	EIMSK = (1<<PCIE1) | (1<<PCIE0);
	
	CLKPR = 0x80;
	CLKPR = 0x00;
}