#ifndef WRITE_H_
#define WRITE_H_

#include "TinyTimber.h"
#include "init.h"
#include "pulse.h"
#include <avr/io.h>

typedef struct {
	Object super;
} write;

#define initwriter() { initObject() }

void port1(write *self, int bit);
void port0(write *self, int bit);

#endif