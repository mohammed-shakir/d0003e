#include "TrafficLight.h"

void writerr(TrafficLight *self){
	while ((UCSR0A & (1 << UDRE0)) == 0) {};
	UDR0 = (self->northGreenLightStatus << 0) | (self->northRedLightStatus << 1) | (self->southGreenLightStatus << 2) | (self->southRedLightStatus << 3);
}

void trafficLight(TrafficLight* self, int v) {
	if (self->northGreenLightStatus == 1 || (self->northGreenLightStatus == 0 && self->southGreenLightStatus == 0)) {
		self->northGreenLightStatus = 0;
		self->southGreenLightStatus = 1;
		self->northRedLightStatus = 1;
		self->southRedLightStatus = 0;
		ASYNC(self, writerr, 0);
	}
	
	else if (self->southGreenLightStatus == 1) {
		self->northGreenLightStatus = 1;
		self->southGreenLightStatus = 0;
		self->northRedLightStatus = 0;
		self->southRedLightStatus = 1;
		ASYNC(self, writerr, 0);
	}
	
	AFTER(SEC(10), self, trafficLight, 0);

	/*
	if (self->southGreenLightStatus == 1) {
		if (self->north > 0 && self->passed > 3) {
			self->northGreenLightStatus = 0;
			self->southGreenLightStatus = 0;
			self->northRedLightStatus = 1;
			self->southRedLightStatus = 1;
			writerr(self);
			self->switchTo = 1;
		}
		
		if (self->south == 0 && self->north > 0) {
			self->northGreenLightStatus = 0;
			self->southGreenLightStatus = 0;
			self->northRedLightStatus = 1;
			self->southRedLightStatus = 1;
			writerr(self);
			self->switchTo = 1;
		}
	}
	
	
	if (self->northGreenLightStatus == 1) {
		if (self->south > 0 && self->passed > 3) {
			self->northGreenLightStatus = 0;
			self->southGreenLightStatus = 0;
			self->northRedLightStatus = 1;
			self->southRedLightStatus = 1;
			writerr(self);
			self->switchTo = 2;
		}
		
		if (self->north == 0 && self->south > 0) {
			self->northGreenLightStatus = 0;
			self->southGreenLightStatus = 0;
			self->northRedLightStatus = 1;
			self->southRedLightStatus = 1;
			writerr(self);
			self->switchTo = 2;
		}
	}
	
	if (self->southGreenLightStatus == 0 && self->northGreenLightStatus == 0) {
		if (self->bro == 0 && self->switchTo == 1) {
			self->northGreenLightStatus = 1;
			self->southGreenLightStatus = 0;
			self->northRedLightStatus = 0;
			self->southRedLightStatus = 1;
			self->passed = 0;
			self->switchTo = 0;
			writerr(self);
		}
		
		if (self->bro == 0 && self->switchTo == 2) {
			self->northGreenLightStatus = 0;
			self->southGreenLightStatus = 1;
			self->northRedLightStatus = 1;
			self->southRedLightStatus = 0;
			self->passed = 0;
			self->switchTo = 0;
			writerr(self);
		}
	}
	*/
}