#ifndef Volvo_H_
#define Volvo_H_

#include "TinyTimber.h"
#include "GUI.h"
#include "Init.h"
#include <stdbool.h>

typedef struct{
	Object super;
	int cars;
	int direction;
	int counter;
} Volvo;

#define initSupra() {initObject(), 0, 0, 0}
	
void enterQueue(Volvo* self, int v);
void exitQueue(Volvo* self, int v);
void enterBridge(Volvo* self, int v);
void exitBridge(Volvo* self, int v);
void update(Volvo* self, int v);


#endif /* SUPRA_H_ */