#ifndef TRAFFICLIGHT_H_
#define TRAFFICLIGHT_H_

#include "TinyTimber.h"
#include "Init.h"

typedef struct  
{
	Object super;
	int southGreenLightStatus;
	int northGreenLightStatus;
	int southRedLightStatus;
	int northRedLightStatus;
} TrafficLight;

#define initTrafficLight(sim) {initObject(), 0, 0, 0, 0}
	
void trafficLight(TrafficLight* self, int v);
void writerr(TrafficLight *self);

#endif