#ifndef CONTROLLER_H_
#define CONTROLLER_H_

#include "TinyTimber.h"
#include "TrafficLight.h"
#include "Volvo.h"

typedef struct  
{
	Object super;
	TrafficLight *traff;
	Volvo *south;
	Volvo *bro;
	Volvo *north;
} Controller;

#define initController(traff, south, bro, north) {initObject(), traff, south, bro, north}
	
void HandleInput(Controller *self);
void start(Controller *self);

#endif