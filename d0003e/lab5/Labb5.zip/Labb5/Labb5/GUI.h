#ifndef GUI_H_
#define GUI_H_

#include <stdint.h>
#include <avr/io.h>
#include "TinyTimber.h"
#include "GUI.h"

typedef struct{
	Object super;
} GUI;

#define initGUI() {initObject()};

void writeChar(GUI* self, char ch, int pos);
void printAt(GUI* self, int num, int pos);
void North(GUI* self, int v);
void South(GUI* self, int v);
void onBridge(GUI* self, int v);

#endif