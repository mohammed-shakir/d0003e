#include <avr/io.h>
#include <avr/interrupt.h>
#include "TinyTimber.h"
#include "GUI.h"
#include "TrafficLight.h"
#include "Init.h"
#include "Volvo.h"
#include "Controller.h"

#define FOSC 8000000UL // Clock Speed
#define BAUD 9600
#define MYUBRR FOSC/16/BAUD-1

TrafficLight light = initTrafficLight();
Volvo south = initSupra();
Volvo bro = initSupra();
Volvo north = initSupra();
Controller controller = initController(&light, &south, &bro, &north);


int main(void)
{
	LCD_Init();
	USART_Init(MYUBRR);
	
    INSTALL(&controller, HandleInput, IRQ_USART0_RX);	
	
	sei();
	
    return TINYTIMBER(&controller, start, 0);
}