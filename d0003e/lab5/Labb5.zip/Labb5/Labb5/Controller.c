#include "Controller.h"

void HandleInput(Controller *self){							
	if (UDR0 & (1 << 0))
	{
		ASYNC(self->north, enterQueue, 4);
	}
	else if(UDR0 & (1 << 1)){
		AFTER(MSEC(1000), self->north, exitQueue, 4);
		AFTER(MSEC(1000), self->bro, enterBridge, 2);
	}
	else if(UDR0 & (1 << 2)){
		ASYNC(self->south, enterQueue, 0);
	}
	else if(UDR0 & (1 << 3)){
		AFTER(MSEC(1000), self->south, exitQueue, 0);
		AFTER(MSEC(1000), self->bro, enterBridge, 2);
	}
}

void start(Controller *self){
	ASYNC(self->south, update, 0);
	ASYNC(self->bro, update, 2);
	ASYNC(self->north, update, 4);
	ASYNC(self->traff, trafficLight, 0);
}