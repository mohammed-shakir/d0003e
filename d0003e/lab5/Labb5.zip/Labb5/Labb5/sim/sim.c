#include <stdio.h>
#include <termios.h>
#include <fcntl.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <stdint.h>
#include <inttypes.h>
#include <stdbool.h>

pthread_t control;
pthread_t gui;
pthread_t bridge;

pthread_mutex_t mTL;
pthread_mutex_t mSN;

int b = 0;

typedef struct {
	int nBuffer;
	int sBuffer;
	int s_bridge;
	int n_bridge;
	int nLight;
	int sLight;
} Controller;

Controller con = {0, 0, 0, 0, 0, 0};
int COM1;

void Initialize() {
	struct termios tc;
	COM1 = open("/dev/ttyS0", O_RDWR);
	
	tcgetattr(COM1, &tc);

	tcflush(COM1, TCIFLUSH); // Reset all attributes

	cfsetispeed(&tc, B9600); // Input Speed
	cfsetospeed(&tc, B9600); // Output Speed
	
	tc.c_cflag |= CLOCAL | CREAD; 
	tc.c_cflag |= B9600 | CS8;
	tc.c_cflag |= HUPCL | INPCK | CSTOPB;
	
	tc.c_lflag &= ~(ECHO | ECHONL | IEXTEN | ICANON);
	
	tc.c_cc[VTIME] = 10;
	tc.c_cc[VMIN] = 1;
	
	tcsetattr(COM1, TCSANOW, &tc);
}

void writeSerial(uint8_t msg) {
	pthread_mutex_lock(&mSN);
	write(COM1, &msg, sizeof(msg)); // send message to Butterfly
	pthread_mutex_unlock(&mSN);
}

void* GUI(void* a) {
	while (1) {
		system("clear");
		printf("        |                                                            |\n");
		printf("        |                                                            |\n");
		printf("       | |                                                          | |\n");
		printf("      |   |                                                        |   |\n");
		printf("      |   |                                                        |   |\n");
		if(con.nLight == 1) {
			printf("      |( )|                                                        |(@)|\n");
		}
		if(con.sLight == 1) {
			printf("      |(@)|                                                        |( )|\n");
		}
		if(con.nLight == 0 && con.sLight == 0) {
			printf("      |( )|                                                        |( )|\n");
		}
		if(con.sBuffer > 0 && con.nBuffer > 0){
			printf("__    |   |                                                        |   |    __\n");
			printf("[]\\_  |   |                                                        |   |  _/[]\n");
			printf("---@}_|   |________________________________________________________|   |_{@---\n");
		}
		else if(con.sBuffer > 0){
			printf("__    |   |                                                        |   |      \n");
			printf("[]\\_  |   |                                                        |   |      \n");
			printf("---@}_|   |________________________________________________________|   |______\n");
		}
		else if(con.nBuffer > 0){
			printf("      |   |                                                        |   |    __\n");
			printf("      |   |                                                        |   |  _/[]\n");
			printf("______|   |________________________________________________________|   |_{@---\n");
		}
		else {
			printf("      |   |                                                        |   |      \n");
			printf("      |   |                                                        |   |      \n");
			printf("______|   |________________________________________________________|   |______\n");
		}
			
		printf("======|   |========================================================|   |======\n");
		printf("      |[%d]|                                                        |[%d]|      \n", con.sBuffer, con.nBuffer);
		printf("      |   |                                                        |   |\n");
		printf("______|___|__________________________[%d]___________________________|___|______\n", con.s_bridge + con.n_bridge);

		fflush(stdout);
		usleep(80000);
	}
}




void* Control(void* a) {
	uint8_t serialIn;
	while(1) {
		pthread_mutex_lock(&mSN);
		int data = read(COM1, &serialIn, sizeof(serialIn));
		
		if(data > 0) {
			con.nLight = serialIn & 0b0001;
			con.sLight = (serialIn/0b100) & 0b0001;
		}
	}
}

void* enterBridge(void* a) {
	int dir = (int)a;
	
	pthread_mutex_lock(&mTL);
	
	if(dir == 0) {
		con.sBuffer--;
		con.s_bridge++;
	} else {
		con.nBuffer--;
		con.n_bridge++;
	}
	
	pthread_mutex_unlock(&mTL);
	
	if(dir == 0) {
		writeSerial(0b1000);
		} else {
		writeSerial(0b0010);
	}
	
	usleep(5000000);
	
	pthread_mutex_lock(&mTL);
	
	if(dir == 0) {
		con.s_bridge--;
		} else {
		con.n_bridge--;
	}
	pthread_mutex_unlock(&mTL);
}

void carOnBridge(void* a) {
	while(1) {
		
		if(con.nLight && con.nBuffer > 0 && con.s_bridge == 0) {
			b = 1;
			pthread_t car_thread;
			pthread_create(&car_thread, NULL, enterBridge, 1);
		}
		
		else if(con.sLight && con.sBuffer > 0 && con.n_bridge == 0) {
			b = 1;
			pthread_t car_thread;
			pthread_create(&car_thread, NULL, enterBridge, 0);
			
		}
		
		if (b == 1) {
			b = 0;
			usleep(1000000);
		}
	}
}

void inputHandler() {
	while(1) {
		
			char ch = getchar();
			if(ch == 'a') {
				pthread_mutex_lock(&mTL);
				con.nBuffer++;
				writeSerial(0b0001);
				pthread_mutex_unlock(&mTL);
			} 
			
			else if(ch == 'd') {
				pthread_mutex_lock(&mTL);
				con.sBuffer++;
				writeSerial(0b0100);
				pthread_mutex_unlock(&mTL);
			}
			
			else if(ch == 's') {
				exit(0);
				break;
			}
		
	}
}
int main() {
	Initialize();
	pthread_create(&control, NULL, Control, 0);
	pthread_create(&gui, NULL, GUI, 0);
	pthread_create(&bridge, NULL, carOnBridge, 0);
	inputHandler();
	return 0;
}