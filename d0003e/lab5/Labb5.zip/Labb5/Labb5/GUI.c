#include <avr/io.h>
#include "GUI.h"

writeChar(GUI* self, char ch, int pos) {
	int numbers[] = {0x1551, 0x0110, 0x11E1, 0x11B1, 0x05B0, 0x14b1, 0x14F1, 0x1110, 0x15F1, 0x15B1};
	uint8_t *lcddr = (uint8_t *) 0xEC;
	
	int inted = (int)ch - 48;
	int num = numbers[inted];
	
	if(pos < 0 || pos > 5) {
		return 0;
	}
	
	*(lcddr+15+pos/2) = (*(lcddr+15+pos/2) & ( 0x0f * (1+((pos+1)%2)*15))) + (num & 0x000f) * (1+(pos%2)*15);
	*(lcddr+10+pos/2) = (*(lcddr+10+pos/2) & ( 0x0f * (1+((pos+1)%2)*15))) + (num & 0x00f0)/16 * (1+(pos%2)*15);
	*(lcddr+5+pos/2) = (*(lcddr+5+pos/2) & ( 0x0f * (1+((pos+1)%2)*15))) + (num & 0x0f00)/256 * (1+(pos%2)*15);
	*(lcddr+pos/2) = (*(lcddr+pos/2) & ( 0x0f * (1+((pos+1)%2)*15))) + (num & 0xf000)/4096 * (1+(pos%2)*15);
}

void printAt(GUI* self, int num, int pos) {
	int pp = pos;
	writeChar(self, (num % 100) / 10 + '0', pp);
	pp++;
	writeChar(self, num % 10 + '0', pp);
}

void South(GUI* self, int v) {
	printAt(self, v, 0);
}

void onBridge(GUI* self, int v) {
	printAt(self, v, 2);
}

void North(GUI* self, int v) {
	printAt(self, v, 4);
}