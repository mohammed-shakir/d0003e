#include "Volvo.h"
	
void enterQueue(Volvo* self, int v) {
	self->cars++;
	update(self, v);
}

void exitQueue(Volvo* self, int v) {
	self->cars--;
	update(self, v);
	// enterBridge(self, 0);
}

void enterBridge(Volvo* self, int v) {
	self->cars++;
	update(self, 2);
	AFTER(SEC(5), self, exitBridge, 2);
}

void exitBridge(Volvo* self, int v) {
	self->cars--;
	update(self, 2);
}

void update(Volvo* self, int v) {
	if (v == 0) {
		ASYNC(self, South, self->cars);
	}
	
	else if (v == 2) {
		ASYNC(self, onBridge, self->cars);
	}
	
	else if (v == 4) {
		ASYNC(self, North, self->cars);
	}
}