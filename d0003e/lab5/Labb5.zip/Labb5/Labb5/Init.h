#ifndef Init_H_
#define Init_H_

#include <avr/io.h>
#include "TinyTimber.h"

void LCD_Init(void);
void IO_Init(void);
void USART_Init(unsigned int ubrr);

#endif