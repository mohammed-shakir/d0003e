#include "tinythreads.h"
#include "tinythreads.c"
#include <stdbool.h>
#include <avr/io.h>

int presses = 0;

void LCD_Init(void) {
	LCDCRB = (1<<LCDCS) | (1<<LCDMUX1) | (1<<LCDMUX0) | (1<<LCDPM2) | (1<<LCDPM1) | (1<<LCDPM0);
	LCDFRR = (1<<LCDCD2) | (1<<LCDCD1) | (1<<LCDCD0);
	LCDCCR = (1<<LCDCC3) | (1<<LCDCC2) | (1<<LCDCC1) | (1<<LCDCC0);
	LCDCRA = (1<<LCDEN)| (1<<LCDAB);
}

int writeChar(char ch, int pos) {
	int numbers[] = {0x1551, 0x0110, 0x11E1, 0x11B1, 0x05B0, 0x14b1, 0x14F1, 0x1110, 0x15F1, 0x15B1};
	uint8_t *lcddr = (uint8_t *) 0xEC;
	
	int inted = (int)ch - 48;
	int num = numbers[inted];
	
	if(pos < 0 || pos > 5) {
		return 0;
	}
	
	*(lcddr+15+pos/2) = (*(lcddr+15+pos/2) & ( 0x0f * (1+((pos+1)%2)*15))) + (num & 0x000f) * (1+(pos%2)*15);
	*(lcddr+10+pos/2) = (*(lcddr+10+pos/2) & ( 0x0f * (1+((pos+1)%2)*15))) + (num & 0x00f0)/16 * (1+(pos%2)*15);
	*(lcddr+5+pos/2) = (*(lcddr+5+pos/2) & ( 0x0f * (1+((pos+1)%2)*15))) + (num & 0x0f00)/256 * (1+(pos%2)*15);
	*(lcddr+pos/2) = (*(lcddr+pos/2) & ( 0x0f * (1+((pos+1)%2)*15))) + (num & 0xf000)/4096 * (1+(pos%2)*15);
}

int is_prime(long i) {
	if (i <= 1)
	return 0;

	for (int n = 2; n < i; n++) {
		if (i % n == 0) {
			return 0;
		}
	}
	return 1;
}

void printAt(long num, int pos) {
	int pp = pos;
	writeChar( (num % 100) / 10 + '0', pp);
	pp++;
	writeChar( num % 10 + '0', pp);
}

void computePrimes(int pos) {
	long n;
	for(n = 1; ; n++) {
		if (is_prime(n)) {
			printAt(n, pos);
		}
	}
}
void blink() {
	LCDDR3 ^= 0x01;
}

button(int pos) {
	LCDDR13 ^= 0x01;
	LCDDR18 ^= 0x01;
	presses++;
	printAt(presses, pos);
}

void regs(void)
{
	// Button
	PORTB = (1<<7);
	PCMSK1 = (1<<PCINT15);
	EIMSK = (1<<PCIE1);
	
	// Timer
	TCCR1A = (1<<COM1A1) | (1<<COM1A0);
	TCCR1B = (1<<WGM12) | (1<<CS12) | (1<<CS10);
	OCR1A = 3906; // (8000000/1024)*0.5 (Because we want 0.5 seconds on screen and 0.5 seconds off screen)
	TCNT1 = 0x0;
	TIMSK1 = (1<<OCIE1A);
	
}

ISR(TIMER1_COMPA_vect) {
	spawn(blink, 0);
}

ISR(PCINT1_vect){
	if((PINB >> 7) == 0) {
		spawn(button, 4);
	}
}

int main() {
	CLKPR = 0x80;
	CLKPR = 0x00;
	
	LCD_Init();
	regs();
	
	spawn(blink, 0);
	spawn(button, 4);
	computePrimes(0);
}